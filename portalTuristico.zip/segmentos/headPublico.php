<!-- Favicon -->
<link href="assets/img/theme/logo-riohurtado-mobil.png" rel="icon" type="image/png">
<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- Icons -->
<link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
<link href="./assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!-- Argon CSS -->
<link type="text/css" href="./assets/css/argon.css?v=1.0.1" rel="stylesheet">
<!-- Docs CSS -->
<link type="text/css" href="./assets/css/docs.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.2/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.0.2/dist/leaflet.js"></script>

<script src="https://mappinggis.com/visores_webmapping/leaflet-routing-machine-3.2.5/dist/leaflet-routing-machine.js"></script>
<link rel="stylesheet" href="https://mappinggis.com/visores_webmapping/leaflet-routing-machine-3.2.5/dist/leaflet-routing-machine.css" />

